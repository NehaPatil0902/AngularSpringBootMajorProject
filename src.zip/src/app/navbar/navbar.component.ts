import { Component, OnInit } from '@angular/core';
//STEP 1 - REDIRECTING
import { Router } from '@angular/router';
import { Navbar } from '../navbar';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  navbar: Navbar[];
  constructor(){ 
 
  this.navbar = [
    {
      sno:1,
      title: "This is Title",
      desc: "DEscription",
      active: true
    },
    {
      sno:2,
      title: "This is Title1",
      desc: "DEscription",
      active: true
    }
  ]
  
  }
ngOnInit(): void {
    
}
}