import { Component, OnInit } from '@angular/core';

//1. IMPORT ROUTER FOR REDIRECTING
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})

export class AdminloginComponent implements OnInit {
  public adminloginid: string = "";
  public adminpassword: string = "";

  //CREATE VERIABLE FOR HIDE/VISIBLE ERROR MESSAGE
  public noerrormsgvisible = true;

  //2. CREATE ROUTER CLASS OBJECT AND INJECT IT TROUGH CONSTRUCTOR
  constructor(public router: Router) { }

  onSubmit() {
    //console.log(this.adminloginid);
    //console.log(this.adminpassword);

    var uidmatch = this.adminloginid.localeCompare("admin");
    var passmatch = this.adminpassword.localeCompare("admin");

    if ((uidmatch == 0) && (passmatch == 0)) {
      console.log(" WELCOME ADMIN : Match");

      // STORE VALUE IN SESSION [KEY : VALUE]
      localStorage.setItem('usertype', 'ADMIN');
      sessionStorage.setItem('usertype', 'ADMIN');

      //3. REDIRECT TO ADMIN_AFTER_LOGIN_COMPONENT
      this.router.navigate(['/adminafterlogin']);

    }
    else {
      console.log(" WRONG USERID OR PASSWORD ");

      //DISPLAY ERROR MSG
      this.noerrormsgvisible = false;

      //CLEAR THE FIELD
      this.adminloginid = "";
      this.adminpassword = "";
    }

  }

  ngOnInit(): void {
  }

}
