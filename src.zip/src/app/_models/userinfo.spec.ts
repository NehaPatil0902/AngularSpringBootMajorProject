import { Userinfo } from './userinfo';

describe('Userinfo', () => {
  it('should create an instance', () => {
    expect(new Userinfo()).toBeTruthy();
  });
});
