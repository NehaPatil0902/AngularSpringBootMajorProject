export class Userinfo {
    public rollno: string = "";
    public name: string = "";
    public lname: string = "";
    public email: string = "";
    public password: string = "";
    public mobile: string = "";
    public address: string = "";
    public gender: string = "";
    public birth: string = "";
    
    
}
