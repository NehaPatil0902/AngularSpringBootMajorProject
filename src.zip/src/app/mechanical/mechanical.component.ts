import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mechanical',
  templateUrl: './mechanical.component.html',
  styleUrls: ['./mechanical.component.css']
})
export class MechanicalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
