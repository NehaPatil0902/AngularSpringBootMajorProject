import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_services/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admindeleteuser',
  templateUrl: './admindeleteuser.component.html',
  styleUrls: ['./admindeleteuser.component.css']
})
export class AdmindeleteuserComponent implements OnInit {
  public rollno: string = "";
  name = ""
  showmsg = ""

  constructor(public adminserviceobj: AdminService,public router:Router) { }

  onSubmit() {
    console.log("INSIDE ONSUBMIT METHOD");
    console.log(this.rollno);

    //FOR INSERT
    this.adminserviceobj.deleterecordbyrollno(this.rollno)
      .subscribe((res: any) => {
        console.log("RETURN BACK");
        console.log(res)
        if (res != null)
          this.showmsg = "RECORD DELETED"
        else
          this.showmsg = "INVALID NAME"

        this.rollno = ""
      });

  }

  ngOnInit(): void {
  }
  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }


}
