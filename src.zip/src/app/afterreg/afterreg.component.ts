import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Userinfo } from '../_models/userinfo';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-afterreg',
  templateUrl: './afterreg.component.html',
  styleUrls: ['./afterreg.component.css']
})
export class AfterregComponent implements OnInit {

  constructor(public router: Router) {
    this.uobj = JSON.parse(localStorage.getItem('userinfo'))
   }

   uobj:any

  ngOnInit(): void {

  }
  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }
}
