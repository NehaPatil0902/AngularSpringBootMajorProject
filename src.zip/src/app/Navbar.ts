export class Navbar{
    sno: number
    title: string
    desc: string
    active: boolean
}