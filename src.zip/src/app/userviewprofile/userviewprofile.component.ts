import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-userviewprofile',
  templateUrl: './userviewprofile.component.html',
  styleUrls: ['./userviewprofile.component.css']
})
export class UserviewprofileComponent implements OnInit {

  uobj:any
  
  constructor(public router: Router) { }

  ngOnInit(): void {
    this.uobj = JSON.parse(localStorage.getItem('userinfo'))
  }

  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }
}
