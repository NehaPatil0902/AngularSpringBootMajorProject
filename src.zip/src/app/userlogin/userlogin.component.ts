import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Userinfo } from '../_models/userinfo';
import { UserService } from '../_services/user.service';
import { stringify } from 'querystring';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  public showmsg = ""

  //CREATE ROUTER CLASS OBJECT AND INJECT IT THROUGH CONSTRUCTOR
  constructor(public userobj: Userinfo, public userserviceobj:UserService, public routerobj: Router ) { }
  onSubmit(form: NgForm) {
    console.log("INSIDE ONSUBMIT METHOD");
    
    console.log(this.userobj.email);
    console.log(this.userobj.password);
  
  
    
      //FOR INSERT
      this.userserviceobj.userLoginCheck(this.userobj)
      .subscribe((res: any) => {
        console.log("RETURN BACK FROM SERVER");
        console.log(res)

        if(res != null){

          localStorage.setItem('userinfo', JSON.stringify(res));

          //REDIRECT TO ADMIN_AFTER_LOGIN_COMPONENT
          this.routerobj.navigate(['/userafterlogin']);
        }
        else{
          this.showmsg = "INVALID UID OR PASSWORD"
        }

        
      });

      //CLEAR FORM
      this.resetRegForm(form);
  }

  resetRegForm(form: NgForm) {
    form.resetForm();
  }

  

    ngOnInit(): void {
  }
  
}