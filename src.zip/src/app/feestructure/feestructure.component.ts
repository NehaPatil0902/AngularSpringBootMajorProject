import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feestructure',
  templateUrl: './feestructure.component.html',
  styleUrls: ['./feestructure.component.css']
})
export class FeestructureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
