import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Userinfo } from '../_models/userinfo';
import { AdminService } from '../_services/admin.service';

@Component({
  selector: 'app-adminviewalluser',
  templateUrl: './adminviewalluser.component.html',
  styleUrls: ['./adminviewalluser.component.css']
})
export class AdminviewalluserComponent implements OnInit {
  userobjarr: Userinfo[];
  constructor(public uobj: Userinfo, public aserviceobj: AdminService, public router:Router) { }

  ngOnInit(): void {
    console.log("INSIDE ngoninit METHOD");

    this.aserviceobj.fetchalluserdetails()
      .subscribe((res: any) => {
        console.log("RETURN BACK");
        console.log(res);
        this.userobjarr = res;
      });
  }
  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }

}
