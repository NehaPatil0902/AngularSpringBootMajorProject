import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';

import { Userinfo } from './_models/userinfo';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegComponent } from './reg/reg.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AdminafterloginComponent } from './adminafterlogin/adminafterlogin.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserafterloginComponent } from './userafterlogin/userafterlogin.component';
import { AfterregComponent } from './afterreg/afterreg.component';
import { UserviewprofileComponent } from './userviewprofile/userviewprofile.component';
import { UserupdateprofileComponent } from './userupdateprofile/userupdateprofile.component';
import { ComputerComponent } from './computer/computer.component';
import { CivilComponent } from './civil/civil.component';
import { MechanicalComponent } from './mechanical/mechanical.component';
import { ElectricalComponent } from './electrical/electrical.component';
import { InstruComponent } from './instru/instru.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { AdminsearchuserComponent } from './adminsearchuser/adminsearchuser.component';
import { AdminviewalluserComponent } from './adminviewalluser/adminviewalluser.component';
import { AdmindeleteuserComponent } from './admindeleteuser/admindeleteuser.component';
import { AdmissiondetailsComponent } from './admissiondetails/admissiondetails.component';
import { FeestructureComponent } from './feestructure/feestructure.component';
import { EnrollComponent } from './enroll/enroll.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegComponent,
    UserloginComponent,
    AdminloginComponent,
    NavbarComponent,
    AdminafterloginComponent,
    ContactusComponent,
    AboutusComponent,
    HeaderComponent,
    FooterComponent,
    UserafterloginComponent,
    AfterregComponent,
    UserviewprofileComponent,
    UserupdateprofileComponent,
    ComputerComponent,
    CivilComponent,
    MechanicalComponent,
    ElectricalComponent,
    InstruComponent,
    ElectronicsComponent,
   
    AdminsearchuserComponent,
        AdminviewalluserComponent,
        AdmindeleteuserComponent,
        AdmissiondetailsComponent,
        FeestructureComponent,
        EnrollComponent,
        
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [Userinfo],
  bootstrap: [AppComponent]
})
export class AppModule { }
