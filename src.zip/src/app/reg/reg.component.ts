import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Userinfo } from '../_models/userinfo';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css']
})
export class RegComponent implements OnInit {

  
  public showmsg = ""

  
  constructor(public userobj:Userinfo, public userserviceobj:UserService,  public routerobj: Router  ) {
    this.uobj = JSON.parse(localStorage.getItem('userinfo'))
   }
  
  uobj:any

  onSubmit(form: NgForm) {
    
    console.log("INSIDE ONSUBMIT METHOD");
    
  
    
    
      this.userserviceobj.addUserRecord(this.userobj)
      .subscribe((res: any) => {
        console.log("RETURN BACK");
        console.log(res)

        this.showmsg = "REGISTRATION SUCCESSFUL"

        //REDIRECT TO ADMIN_AFTER_LOGIN_COMPONENT
        this.routerobj.navigate(['/afterreg']);
      });

      //CLEAR FORM
      this.resetRegForm(form);
  }


  resetRegForm(form: NgForm) {
    form.resetForm();
  }

  

    ngOnInit(): void {
    }
    
    

      
  

}
