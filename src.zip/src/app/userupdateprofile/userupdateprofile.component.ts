import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Userinfo } from '../_models/userinfo';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userupdateprofile',
  templateUrl: './userupdateprofile.component.html',
  styleUrls: ['./userupdateprofile.component.css']
})
export class UserupdateprofileComponent implements OnInit {


  public showmsg = ""

  constructor(public userobj: Userinfo, public userserviceobj: UserService, public routerobj: Router, public router: Router) {
    let uobj = JSON.parse(localStorage.getItem('userinfo'))

    userobj.email = uobj.email
    userobj.name = uobj.name
    userobj.lname = uobj.lname
    userobj.password = uobj.password
    userobj.gender = uobj.gender
    userobj.mobile = uobj.mobile
    userobj.birth = uobj.birth
    userobj.address = uobj.address
  }

  onSubmit(form: NgForm) {
    console.log("INSIDE ONSUBMIT METHOD");
    // console.log(this.userobj.rollno);
    // console.log(this.userobj.name);
    // console.log(this.userobj.email);

    //FOR INSERT
    this.userserviceobj.userProfileUpdateByEmail(this.userobj)
      .subscribe((res: any) => {
        console.log("RETURN BACK");
        console.log(res)

        localStorage.setItem('userinfo', JSON.stringify(res));

        //this.showmsg = "PROFILE UPDATED"
        this.routerobj.navigate(['/userviewprofile']);
      });

    //CLEAR FORM
    this.resetRegForm(form);
  }

  resetRegForm(form: NgForm) {
    form.resetForm();
  }

  ngOnInit(): void {

  }
  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }

}
