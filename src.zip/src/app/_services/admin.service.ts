import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(public http: HttpClient) { }

  fetchalluserdetails() {
    return this.http.get('http://localhost:8080/fetchalluserdetails');

  }

  deleterecordbyrollno(rollno) {
    return this.http.delete('http://localhost:8080/deleterecordbyrollno' + `/${rollno}`);

  }

  

  searchmultipleuserbyname(name) {
    return this.http.get('http://localhost:8080/searchmultipleuserbyname' + `/${name}`);

  }
}
