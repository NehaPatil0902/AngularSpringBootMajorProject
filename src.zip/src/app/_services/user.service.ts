import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  
  constructor(private http: HttpClient) { }

  addUserRecord(userobj:any) {
    return this.http.post('http://localhost:8080/adduserrecord', userobj);
  }
 
  userLoginCheck(userobj:any) {
    return this.http.post('http://localhost:8080/userlogincheck', userobj);
  }

  userProfileUpdateByEmail(userobj:any) {
    return this.http.put('http://localhost:8080/userprofileupdatebyemail', userobj);
  }
 
 
  

}
