import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstruComponent } from './instru.component';

describe('InstruComponent', () => {
  let component: InstruComponent;
  let fixture: ComponentFixture<InstruComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstruComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstruComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
