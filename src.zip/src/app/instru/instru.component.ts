import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instru',
  templateUrl: './instru.component.html',
  styleUrls: ['./instru.component.css']
})
export class InstruComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
