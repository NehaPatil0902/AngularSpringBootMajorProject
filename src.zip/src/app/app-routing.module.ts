import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserafterloginComponent } from './userafterlogin/userafterlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminafterloginComponent } from './adminafterlogin/adminafterlogin.component';
import { RegComponent } from './reg/reg.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AfterregComponent } from './afterreg/afterreg.component';
import { UserviewprofileComponent } from './userviewprofile/userviewprofile.component';
import { UserupdateprofileComponent } from './userupdateprofile/userupdateprofile.component';
import { ComputerComponent } from './computer/computer.component';
import { CivilComponent } from './civil/civil.component';
import { MechanicalComponent } from './mechanical/mechanical.component';
import { ElectricalComponent } from './electrical/electrical.component';
import { InstruComponent } from './instru/instru.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { AdminsearchuserComponent } from './adminsearchuser/adminsearchuser.component'
import { AdminviewalluserComponent } from './adminviewalluser/adminviewalluser.component';
import { AdmindeleteuserComponent } from './admindeleteuser/admindeleteuser.component'
import { AdmissiondetailsComponent } from './admissiondetails/admissiondetails.component';
import { FeestructureComponent } from './feestructure/feestructure.component'
import { EnrollComponent } from './enroll/enroll.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'userlogin',
    component: UserloginComponent
  },
  {
    path: 'userafterlogin',
    component: UserafterloginComponent
  },
  {
    path: 'adminlogin',
    component: AdminloginComponent
  },
  {
    path: 'adminafterlogin',
    component: AdminafterloginComponent
  },
  {
    path: 'reg',
    component: RegComponent
  },
  {
    path: 'contactus',
    component: ContactusComponent
  },
  {
    path: 'aboutus',
    component: AboutusComponent
  },
  {
    path: 'afterreg',
    component: AfterregComponent
  },
  {
    path: 'userviewprofile',
    component:  UserviewprofileComponent
  },
  {
    path: 'userupdateprofile',
    component:  UserupdateprofileComponent
  },
  {
    path: 'computer',
    component:  ComputerComponent
  },
  {
    path: 'civil',
    component:  CivilComponent
  },
  {
    path: 'electrical',
    component:  ElectricalComponent
  },
  {
    path: 'electronics',
    component:  ElectronicsComponent
  },
  {
    path: 'instru',
    component:  InstruComponent
  },
  {
    path: 'mechanical',
    component:  MechanicalComponent
  },
  {
    path: 'adminsearchuser',
    component:  AdminsearchuserComponent
  },
  {
    path: 'adminviewalluser',
    component:  AdminviewalluserComponent
  },
  {
    path: 'admindeleteuser',
    component:  AdmindeleteuserComponent
  },
  {
    path: 'admissiondetails',
    component:  AdmissiondetailsComponent
  },
  {
    path: 'feesstructure',
    component:  FeestructureComponent
  },
  {
    path: 'enroll',
    component:  EnrollComponent
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
