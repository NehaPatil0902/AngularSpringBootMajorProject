import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmissiondetailsComponent } from './admissiondetails.component';

describe('AdmissiondetailsComponent', () => {
  let component: AdmissiondetailsComponent;
  let fixture: ComponentFixture<AdmissiondetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdmissiondetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmissiondetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
