import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admissiondetails',
  templateUrl: './admissiondetails.component.html',
  styleUrls: ['./admissiondetails.component.css']
})
export class AdmissiondetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
