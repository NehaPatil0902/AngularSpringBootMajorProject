import { Component, OnInit } from '@angular/core';
import { Userinfo } from '../_models/userinfo';
import { AdminService } from '../_services/admin.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-adminsearchuser',
  templateUrl: './adminsearchuser.component.html',
  styleUrls: ['./adminsearchuser.component.css']
})
export class AdminsearchuserComponent implements OnInit {

  userobjarr: Userinfo[];
  name = ""
  showmsg = ""
  showtable = false

  constructor(public adminserviceobj: AdminService, public router:Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log("INSIDE ONSUBMIT METHOD");
    console.log(this.name);

    //FOR INSERT
    this.adminserviceobj.searchmultipleuserbyname(this.name)
      .subscribe((res: any) => {
        console.log("RETURN BACK");
        console.log(res)

        if (res != null) {
          this.userobjarr = res
          this.showtable = true
        }
        else {
          this.showmsg = "NOT FOUND"
          this.showtable = false

        }

        this.name = ""
      });

  }
  logout(){
    localStorage.removeItem('userinfo');
    localStorage.clear();

    //Redirecting
    this.router.navigate(['/home']);  
  }
}
