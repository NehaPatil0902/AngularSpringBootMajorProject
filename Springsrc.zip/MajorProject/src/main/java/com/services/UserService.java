package com.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.models.UserInfo;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userdbhandleobj;
	
	public UserInfo addUserService(UserInfo userobj) 
	{
		System.out.println("INSIDE addUserService METHOD in SERVICE CLASS");
		System.out.println("Name "+userobj.getName());
		System.out.println("Last Name  "+userobj.getLname());
		System.out.println("Email  "+userobj.getEmail());
		System.out.println("Mobile Number "+userobj.getMobile());
		System.out.println("Address  "+userobj.getAddress());
		System.out.println("Gender "+userobj.getGender());
		System.out.println("BirthDate  "+userobj.getBirth());
		
				
		//After save it return the object which it saved
		userobj =userdbhandleobj.save(userobj);
		
		return userobj;
	}
	
	public UserInfo userLoginCheck(UserInfo userobj) 
	{
		System.out.println("INSIDE userLoginCheck METHOD in SERVICE CLASS");
				
		UserInfo uobj = userdbhandleobj.findByEmail(userobj.getEmail());
		
		if (uobj != null)
		{
			if(uobj.getPassword().equals(userobj.getPassword()))
			{
				return uobj;
			}
		}
		
		return null;
	}
	
	public UserInfo userProfileUpdateByEmail(UserInfo userobj) 
	{
		System.out.println("INSIDE userProfileUpdateByEmail METHOD in SERVICE CLASS");
				
		//IF ID EXIST UPDATE IT, IF NOT EXIST THEN INSERT IT
		userobj = userdbhandleobj.save(userobj);
		
		return userobj;
	}
	
	

}
