package com.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.models.UserInfo;
import com.services.UserService;

@RestController
@CrossOrigin("*")
public class UserController {
	
	@Autowired
	private UserService userviceobj;
	
	@PostMapping("/adduserrecord")
	public UserInfo addUserRecord(@RequestBody UserInfo userobj)
	{
		System.out.println(userobj.getName() +"  "+ userobj.getLname()  + " "+userobj.getEmail()+ "   "+userobj.getPassword() +"  "+ userobj.getMobile() +"  "+ userobj.getAddress() +"  "+ userobj.getGender());
		
		userviceobj.addUserService(userobj);
				
		return(userobj);
	}
	
	@PostMapping("/userlogincheck")
	public UserInfo userLoginCheck(@RequestBody UserInfo userobj)
	{
		UserInfo uobj = userviceobj.userLoginCheck(userobj);
		
		if(uobj != null)
		{
			return uobj;
		}
		else
		{
			return null;
		}
	}
	
	@PutMapping("/userprofileupdatebyemail")
	public UserInfo userProfileUpdateByEmail(@RequestBody UserInfo userobj)
	{
		System.out.println("INSIDE updateUserDetails Method IN CONTROLLER CLASS");
		System.out.println("UPDATED INFORMATION  "+userobj.getEmail());
		System.out.println("UPDATED INFORMATION  "+userobj.getName());
		System.out.println("UPDATED INFORMATION  "+userobj.getLname());
		System.out.println("UPDATED INFORMATION  "+userobj.getMobile());
		System.out.println("UPDATED INFORMATION  "+userobj.getBirth());
		System.out.println("UPDATED INFORMATION  "+userobj.getGender());
		System.out.println("UPDATED INFORMATION  "+userobj.getAddress());
		
		
		return userviceobj.userProfileUpdateByEmail(userobj);
	}
	
}
